# The default keymap for custom_mech
